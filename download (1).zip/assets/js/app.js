(function () {
    function qs(selector, scope) {
        return (scope || document).querySelector(selector);
    }

    function qsa(selector, scope) {
        return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
    }

    var menuBtn = qs("#menuBtn");
    var navDrawer = qs("#navDrawer");

    if (menuBtn && navDrawer) {
        menuBtn.addEventListener("click", function () {
            menuBtn.classList.toggle("open");
            navDrawer.classList.toggle("open");
        });
    }

    qsa("[data-show]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var target = btn.getAttribute("data-show");
            qsa(".view").forEach(function (view) {
                view.classList.remove("active");
            });
            var next = qs("#" + target);
            if (next) next.classList.add("active");
        });
    });

    qsa(".tab-btn").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var parent = btn.closest(".tab-card") || document;
            var tab = btn.getAttribute("data-tab");
            qsa(".tab-btn", parent).forEach(function (b) { b.classList.remove("active"); });
            qsa(".tab-content", parent).forEach(function (c) { c.classList.remove("active"); });
            btn.classList.add("active");
            var target = qs("#" + tab, parent);
            if (target) target.classList.add("active");
        });
    });

    qsa(".tool-tab").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var panel = btn.getAttribute("data-tool");
            qsa(".tool-tab").forEach(function (b) { b.classList.remove("active"); });
            qsa(".tool-panel").forEach(function (p) { p.classList.remove("active"); });
            btn.classList.add("active");
            var target = qs("#" + panel);
            if (target) target.classList.add("active");
        });
    });

    var form = qs("#screeningForm");
    if (form) {
        var current = 1;
        var total = 5;
        var nextBtn = qs("#nextBtn");
        var prevBtn = qs("#prevBtn");
        var submitBtn = qs("#submitBtn");
        var progressBar = qs("#progressBar");

        function showStep() {
            qsa(".step").forEach(function (step) { step.classList.remove("active"); });
            var active = qs('.step[data-step="' + current + '"]');
            if (active) active.classList.add("active");
            if (progressBar) progressBar.style.width = ((current / total) * 100) + "%";
            if (prevBtn) prevBtn.style.visibility = current === 1 ? "hidden" : "visible";
            if (nextBtn) nextBtn.classList.toggle("hidden", current === total);
            if (submitBtn) submitBtn.classList.toggle("hidden", current !== total);
        }

        function validateStep() {
            var active = qs('.step[data-step="' + current + '"]');
            if (!active) return true;
            var fields = qsa("input, select", active);
            for (var i = 0; i < fields.length; i++) {
                if (!fields[i].checkValidity()) {
                    fields[i].reportValidity();
                    return false;
                }
            }
            return true;
        }

        if (nextBtn) {
            nextBtn.addEventListener("click", function () {
                if (!validateStep()) return;
                if (current < total) current++;
                showStep();
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener("click", function () {
                if (current > 1) current--;
                showStep();
            });
        }

        showStep();
    }

    var moodActions = {
        tenang: ["Mood kamu stabil 🌿", "Pertahankan vibe ini. Coba lanjutkan dengan 10 menit aktivitas offline biar tetap balance."],
        overthinking: ["Overthinking detected 🫠", "Tulis 3 hal yang kamu pikirkan, lalu pilih satu yang bisa kamu kendalikan sekarang."],
        capek: ["Energi kamu lagi low 😵‍💫", "Ambil water break, stretching 60 detik, lalu mute notifikasi selama 30 menit."],
        insecure: ["Insecure karena layar? 🥲", "Ingat: feed orang lain itu highlight, bukan full story. Keluar dulu dari akun pemicu perbandingan diri."]
    };

    qsa("[data-mood]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var mood = btn.getAttribute("data-mood");
            var result = qs("#moodResult");
            if (!result || !moodActions[mood]) return;
            result.style.opacity = "0";
            window.setTimeout(function () {
                result.innerHTML = "<h3>" + moodActions[mood][0] + "</h3><p>" + moodActions[mood][1] + "</p>";
                result.style.opacity = "1";
            }, 140);
        });
    });

    var challenges = [
        "No-scroll 20 menit: taruh HP jauh dari tangan, lalu lakukan satu tugas kecil.",
        "Unfollow 3 akun yang bikin kamu merasa kurang cukup.",
        "Mode pesawat 15 menit sebelum tidur malam ini.",
        "Balas 1 chat orang dekat secara tulus, bukan cuma emoji.",
        "Buka galeri, pilih 1 foto real tanpa filter yang kamu suka.",
        "Tukar 10 menit scroll dengan jalan kaki pendek atau stretching."
    ];

    var challengeBtn = qs("#challengeBtn");
    var challengeText = qs("#challengeText");
    if (challengeBtn && challengeText) {
        challengeBtn.addEventListener("click", function () {
            challengeText.style.opacity = "0";
            window.setTimeout(function () {
                challengeText.textContent = challenges[Math.floor(Math.random() * challenges.length)];
                challengeText.style.opacity = "1";
            }, 140);
        });
    }

    var prompts = [
        "Apa satu hal yang sebenarnya kamu butuhkan hari ini?",
        "Hal apa yang bikin kamu merasa cukup tanpa validasi orang lain?",
        "Apa yang bisa kamu kurangi dari media sosial minggu ini?",
        "Siapa satu orang yang bisa kamu hubungi saat pikiran terasa penuh?",
        "Apa pencapaian kecil hari ini yang layak kamu apresiasi?"
    ];

    var promptBtn = qs("#promptBtn");
    var promptText = qs("#promptText");
    if (promptBtn && promptText) {
        promptBtn.addEventListener("click", function () {
            promptText.style.opacity = "0";
            window.setTimeout(function () {
                promptText.textContent = "“" + prompts[Math.floor(Math.random() * prompts.length)] + "”";
                promptText.style.opacity = "1";
            }, 140);
        });
    }

    var timerInterval = null;
    var timerLeft = 300;
    var timerText = qs("#timerText");
    var focusBtn = qs("#focusBtn");
    var resetTimerBtn = qs("#resetTimerBtn");

    function renderTimer() {
        if (!timerText) return;
        var min = String(Math.floor(timerLeft / 60)).padStart(2, "0");
        var sec = String(timerLeft % 60).padStart(2, "0");
        timerText.textContent = min + ":" + sec;
    }

    if (focusBtn && resetTimerBtn && timerText) {
        focusBtn.addEventListener("click", function () {
            if (timerInterval) return;
            focusBtn.textContent = "Focusing...";
            timerInterval = window.setInterval(function () {
                timerLeft--;
                renderTimer();
                if (timerLeft <= 0) {
                    window.clearInterval(timerInterval);
                    timerInterval = null;
                    focusBtn.textContent = "Start Focus";
                    timerLeft = 300;
                    window.setTimeout(renderTimer, 800);
                }
            }, 1000);
        });

        resetTimerBtn.addEventListener("click", function () {
            if (timerInterval) window.clearInterval(timerInterval);
            timerInterval = null;
            timerLeft = 300;
            focusBtn.textContent = "Start Focus";
            renderTimer();
        });
    }
})();
