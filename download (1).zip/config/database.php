<?php
$host = "sql201.infinityfree.com";
$dbname = "if0_41890942_mindcheck";
$username = "if0_41890942";
$password = "dodil2007";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}
?>
